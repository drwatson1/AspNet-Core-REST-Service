﻿namespace $safeprojectname$.Dto
{
    public class Product
    {
        public string Name { get; set; }
    }
}
