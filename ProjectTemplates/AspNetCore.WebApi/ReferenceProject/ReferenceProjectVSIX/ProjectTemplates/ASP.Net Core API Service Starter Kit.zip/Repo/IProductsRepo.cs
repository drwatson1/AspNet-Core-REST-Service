﻿namespace $safeprojectname$.Repo
{
    public interface IProductsRepo: IRepository<Model.Product>
    {
    }
}
