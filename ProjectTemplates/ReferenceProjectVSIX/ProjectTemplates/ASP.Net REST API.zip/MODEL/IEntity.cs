﻿namespace $safeprojectname$.Model
{
    public interface IEntity
    {
        int Id { get; }
    }
}
