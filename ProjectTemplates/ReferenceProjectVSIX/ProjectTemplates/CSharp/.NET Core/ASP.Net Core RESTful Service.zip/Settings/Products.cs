﻿namespace $safeprojectname$.Settings
{
    public class Products
    {
        public string TempFolder { get; set; }
        public string BackendServiceUrl { get; set; }
    }
}
